<?php return array(
    'name' => 'None',
    'description' => 'Emoji aren\'t appropriate for all communities. You can turn them off.',
    'icon' => 'none-icon.png',
    'format' => '<img class="emoji" src="%1$s" title="%2$s" alt="%2$s" />',
    'emoji' => array(),
    'aliases' => array(),
    'editor' => array()
);
