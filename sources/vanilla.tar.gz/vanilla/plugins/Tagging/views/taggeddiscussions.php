<?php if (!defined('APPLICATION')) exit();
include($this->fetchViewLocation('helper_functions', 'discussions', 'vanilla'));
include $this->fetchViewLocation($this->View);
?>
