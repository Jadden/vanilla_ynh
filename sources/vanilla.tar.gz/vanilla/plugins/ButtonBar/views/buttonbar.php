<div class="ButtonBar">
    <div class="BarWrap"><?php
        echo '<span class="ButtonWrap"><span>bold</span></span>';
        echo '<span class="ButtonWrap"><span>italic</span></span>';
        echo '<span class="ButtonWrap"><span>underline</span></span>';
        echo '<span class="ButtonWrap"><span>strike</span></span>';
        echo '<span class="ButtonWrap"><span>code</span></span>';
        echo '<span class="ButtonWrap"><span>image</span></span>';
        echo '<span class="ButtonWrap"><span>url</span></span>';
        echo '<span class="ButtonWrap"><span>quote</span></span>';
        echo '<span class="ButtonWrap"><span>spoiler</span></span>';
        ?></div>
</div>
