<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *
 * Note: this is only here for reference. If you would prefer moving all the
 * view logic externally, then uncomment the below, and uncomment the
 * relevant lines in the class.
 */

//$this->Cf->render();
?>
