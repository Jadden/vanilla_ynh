<?php
header("Location: entry/signin", TRUE, 301);
exit();