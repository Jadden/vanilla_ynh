<?php
header("Location: entry/register", TRUE, 301);
exit();