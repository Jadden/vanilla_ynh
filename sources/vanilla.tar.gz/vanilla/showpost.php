<?php
/**
 * Handles 301 redirecting urls from forums that were imported from phpBB or
 * vBulletin into their Vanilla equivalent pages.
 */

include_once dirname(__FILE__).'/showthread.php';
