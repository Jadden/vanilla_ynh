The conf folder contains the following files:
config-defaults.php - An array of default configuration settings. DO NOT EDIT!
config.php - An array of your custom configuration settings. You can edit this one.
constants.php - Constants for Vanilla.
locale.php - Locale customizations.